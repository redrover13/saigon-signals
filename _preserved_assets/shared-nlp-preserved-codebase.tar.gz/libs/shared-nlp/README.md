# shared-nlp

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build shared-nlp` to build the library.

## Running unit tests

Run `nx test shared-nlp` to execute the unit tests via [Jest](https://jestjs.io).
